# Atom Loading Icon

A Pen created on CodePen.io. Original URL: [https://codepen.io/jonmilner/pen/qBQwQJ](https://codepen.io/jonmilner/pen/qBQwQJ).

