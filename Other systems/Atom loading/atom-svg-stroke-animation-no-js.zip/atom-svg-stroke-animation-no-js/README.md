# 💫 Atom SVG stroke animation no JS 💫

A Pen created on CodePen.io. Original URL: [https://codepen.io/uchardon/pen/NORoXJ](https://codepen.io/uchardon/pen/NORoXJ).

SVG animation electrons circle an atom
only stroke-dashoffset is animated with CSS-keyframes
the electrons are short but wide lines with round linecaps