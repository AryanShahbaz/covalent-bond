# bootstrap 4 navbar

A Pen created on CodePen.io. Original URL: [https://codepen.io/piyushpd139/pen/gOYvZPG](https://codepen.io/piyushpd139/pen/gOYvZPG).

With Bootstrap, a navigation bar can extend or collapse, depending on the screen size. A standard navigation bar is created with the .navbar class, followed by a responsive collapsing class: .navbar-expand-xl. ... sm (stacks the navbar vertically on extra large, large, medium or small screens).