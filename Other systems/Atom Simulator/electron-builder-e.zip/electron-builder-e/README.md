# Electron Builder  e⁻

A Pen created on CodePen.io. Original URL: [https://codepen.io/KingAryan86/pen/jOdVmdy](https://codepen.io/KingAryan86/pen/jOdVmdy).

## Electron Builder e⁻
Electron Builder is a web app for education, based on the electronic distribution proposed by linus pauling it generates a representation of the atom and its electrons in its layers. 